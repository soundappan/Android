package com.example.sivakumar.mywebview;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Button b1;
    ImageView im;

    /* renamed from: com.example.sivakumar.mywebview.MainActivity$1 */
    class C02211 implements OnClickListener {
        C02211() {
        }

        public void onClick(View v) {
            MainActivity.this.startActivity(new Intent(MainActivity.this, Main2Activity.class));
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0222R.layout.activity_main);
        this.b1 = (Button) findViewById(C0222R.id.button);
        this.im = (ImageView) findViewById(C0222R.id.imageView);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setIcon((int) C0222R.mipmap.akshayalogo);
        this.b1.setOnClickListener(new C02211());
    }
}
