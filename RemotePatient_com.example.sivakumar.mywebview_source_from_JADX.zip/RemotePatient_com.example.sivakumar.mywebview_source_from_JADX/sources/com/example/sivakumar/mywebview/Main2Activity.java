package com.example.sivakumar.mywebview;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Main2Activity extends AppCompatActivity {
    WebView wv1;

    private class MyBrowser extends WebViewClient {
        private MyBrowser() {
        }

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setIcon((int) C0222R.mipmap.akshayalogo);
        setContentView((int) C0222R.layout.activity_main2);
        this.wv1 = (WebView) findViewById(C0222R.id.webView);
        this.wv1.setWebViewClient(new MyBrowser());
        this.wv1.getSettings().setLoadsImagesAutomatically(true);
        this.wv1.getSettings().setJavaScriptEnabled(true);
        this.wv1.setScrollBarStyle(0);
        this.wv1.loadUrl("https://m2x.att.com/catalog/34e1e81b2ce4f8cb6c796b81461eefde");
    }
}
