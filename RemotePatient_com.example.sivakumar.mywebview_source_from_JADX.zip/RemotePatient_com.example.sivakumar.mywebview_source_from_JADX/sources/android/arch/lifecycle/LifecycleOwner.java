package android.arch.lifecycle;

public interface LifecycleOwner {
    Lifecycle getLifecycle();
}
