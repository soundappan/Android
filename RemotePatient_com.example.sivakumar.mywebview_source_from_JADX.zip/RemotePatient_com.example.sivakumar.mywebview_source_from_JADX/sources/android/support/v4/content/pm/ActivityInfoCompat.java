package android.support.v4.content.pm;

public final class ActivityInfoCompat {
    public static final int CONFIG_UI_MODE = 512;

    private ActivityInfoCompat() {
    }
}
